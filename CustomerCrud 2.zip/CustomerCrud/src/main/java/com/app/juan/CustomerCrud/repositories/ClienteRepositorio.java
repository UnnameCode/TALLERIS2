package com.app.juan.CustomerCrud.repositories;

public interface ClienteRepositorio extends JpaRepository<Cliente, Long> {

    // Métodos básicos de CRUD
    @Override
    List<Cliente> findAll();
    @Override
    Cliente findById(Long id);
    @Override
    Cliente save(Cliente cliente);
    @Override
    void deleteById(Long id);

    // Búsqueda por nombre
    List<Cliente> findByNombre(String nombre);
    List<Cliente> findByNombreContaining(String nombre);
    List<Cliente> findByNombreStartingWith(String nombre);
    List<Cliente> findByNombreEndingWith(String nombre);

    // Búsqueda por apellidos
    List<Cliente> findByApellidos(String apellidos);
    List<Cliente> findByApellidosContaining(String apellidos);
    List<Cliente> findByApellidosStartingWith(String apellidos);
    List<Cliente> findByApellidosEndingWith(String apellidos);

    // Búsqueda por correo electrónico
    Cliente findByCorreoElectronico(String correoElectronico);

    // Búsqueda por teléfono
    List<Cliente> findByTelefono(String telefono);

    // Búsqueda por nombre y apellidos
    List<Cliente> findByNombreAndApellidos(String nombre, String apellidos);

    // Búsqueda por nombre o apellidos
    List<Cliente> findByNombreOrApellidos(String nombre, String apellidos);

    // Búsqueda por rango de fechas de creación
    List<Cliente> findByFechaCreacionBetween(LocalDate fechaInicio, LocalDate fechaFin);

}
