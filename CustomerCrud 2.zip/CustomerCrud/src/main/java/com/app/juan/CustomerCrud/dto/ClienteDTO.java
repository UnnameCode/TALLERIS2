package com.app.juan.CustomerCrud.dto;

public class ClienteDTO {

    private Long id;
    @ApiModelProperty(name = "Nombre del cliente")
    private String nombre;
    @ApiModelProperty(name = "Dirección del cliente")
    private String direccion;
    @ApiModelProperty(name = "Correo electrónico del cliente")

    private String correoElectronico; public ClienteDTO(Long id, String nombre, String direccion, String correoElectronico) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
    }



}
