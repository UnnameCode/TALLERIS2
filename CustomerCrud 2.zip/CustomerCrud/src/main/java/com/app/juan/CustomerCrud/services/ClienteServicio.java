package com.app.juan.CustomerCrud.services;

@Service
public class ClienteServicio {

    @Auto
    private ClienteRepositorio clienteRepositorio;

    public Cliente crearCliente(ClienteDTO clienteDTO) {
        Cliente cliente = new Cliente();
        cliente.setNombre(clienteDTO.getNombre());
        cliente.setApellidos(clienteDTO.getApellidos());
        cliente.setCorreoElectronico(clienteDTO.getCorreoElectronico());
        cliente.setTelefono(clienteDTO.getTelefono());
        return clienteRepositorio.save(cliente);
    }

    public Cliente obtenerCliente(Long id) {
        return clienteRepositorio.findById(id).orElseThrow(() -> new ClienteNoEncontradoException(id));
    }

    public Cliente actualizarCliente(ClienteDTO clienteDTO) {
        Cliente cliente = clienteRepositorio.findById(clienteDTO.getId()).orElseThrow(() -> new ClienteNoEncontradoException(clienteDTO.getId()));
        cliente.setNombre(clienteDTO.getNombre());
        cliente.setApellidos(clienteDTO.getApellidos());
        cliente.setCorreoElectronico(clienteDTO.getCorreoElectronico());
        cliente.setTelefono(clienteDTO.getTelefono());
        return clienteRepositorio.save(cliente);
    }

    public void eliminarCliente(Long id) {
        clienteRepositorio.deleteById(id);
    }
}

