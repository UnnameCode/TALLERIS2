package org.jfigue.apiservlet.webapp.headers.customercrud;

import org.jfigue.apiservlet.webapp.headers.customercrud.entities.Cliente;
import org.jfigue.apiservlet.webapp.headers.customercrud.repositories.ClienteRepositorio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class ClienteControladorIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ClienteRepositorio clienteRepositorio;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        clienteRepositorio.deleteAll();
    }

    @Test
    void testList() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setNombre("John");
        cliente.setApellidos("Doe");
        cliente.setCorreoElectronico("john.doe@example.com");
        cliente.setTelefono("123456789");
        clienteRepositorio.save(cliente);

        mockMvc.perform(get("/clientes")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(1)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].nombre", is(cliente.getNombre())));
    }

    @Test
    void testView() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setNombre("John");
        cliente.setApellidos("Doe");
        cliente.setCorreoElectronico("john.doe@example.com");
        cliente.setTelefono("123456789");
        cliente = clienteRepositorio.save(cliente);

        mockMvc.perform(get("/clientes/{id}", cliente.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.nombre", is(cliente.getNombre())));
    }

    @Test
    void testCreate() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setNombre("Jane");
        cliente.setApellidos("Doe");
        cliente.setCorreoElectronico("jane.doe@example.com");
        cliente.setTelefono("987654321");

        mockMvc.perform(post("/clientes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(cliente)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.nombre", is(cliente.getNombre())));
    }

    @Test
    void testUpdate() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setNombre("John");
        cliente.setApellidos("Doe");
        cliente.setCorreoElectronico("john.doe@example.com");
        cliente.setTelefono("123456789");
        cliente = clienteRepositorio.save(cliente);

        Cliente updatedCliente = new Cliente();
        updatedCliente.setNombre("Johnny");
        updatedCliente.setApellidos("Doe");
        updatedCliente.setCorreoElectronico("johnny.doe@example.com");
        updatedCliente.setTelefono("123456789");

        mockMvc.perform(put("/clientes/{id}", cliente.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedCliente)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.nombre", is(updatedCliente.getNombre())));
    }

    @Test
    void testDelete() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setNombre("John");
        cliente.setApellidos("Doe");
        cliente.setCorreoElectronico("john.doe@example.com");
        cliente.setTelefono("123456789");
        cliente = clienteRepositorio.save(cliente);

        mockMvc.perform(delete("/clientes/{id}", cliente.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());

        mockMvc.perform(get("/clientes/{id}", cliente.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
}
