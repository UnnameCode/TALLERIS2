package org.jfigue.apiservlet.webapp.headers.customercrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomercrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
