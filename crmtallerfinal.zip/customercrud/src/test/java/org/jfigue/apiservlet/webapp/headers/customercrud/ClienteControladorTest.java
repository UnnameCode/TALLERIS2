// src/test/java/org/jfigue/apiservlet/webapp/headers/customercrud/ClienteControladorTest.java

package org.jfigue.apiservlet.webapp.headers.customercrud;

import org.jfigue.apiservlet.webapp.headers.customercrud.controllers.ClienteControlador;
import org.jfigue.apiservlet.webapp.headers.customercrud.entities.Cliente;
import org.jfigue.apiservlet.webapp.headers.customercrud.services.ClienteServicio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

class ClienteControladorTest {

    @Mock
    private ClienteServicio clienteServicio;

    @InjectMocks
    private ClienteControlador clienteControlador;

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        cliente = new Cliente();
        cliente.setId(1L);
        cliente.setNombre("John");
        cliente.setApellidos("Doe");
        cliente.setCorreoElectronico("john.doe@example.com");
        cliente.setTelefono("123456789");
    }

    @Test
    void testList() {
        List<Cliente> clientes = Arrays.asList(cliente);
        when(clienteServicio.findAll()).thenReturn(clientes);

        List<Cliente> result = clienteControlador.list();

        assertEquals(1, result.size());
        assertEquals("John", result.get(0).getNombre());
    }

    @Test
    void testView() {
        when(clienteServicio.findById(anyLong())).thenReturn(Optional.of(cliente));

        ResponseEntity<?> response = clienteControlador.view(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(cliente, response.getBody());
    }

    @Test
    void testViewNotFound() {
        when(clienteServicio.findById(anyLong())).thenReturn(Optional.empty());

        ResponseEntity<?> response = clienteControlador.view(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testCreate() {
        when(clienteServicio.save(any(Cliente.class))).thenReturn(cliente);

        ResponseEntity<Cliente> response = clienteControlador.create(cliente);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(cliente, response.getBody());
    }

    @Test
    void testUpdate() {
        when(clienteServicio.update(anyLong(), any(Cliente.class))).thenReturn(Optional.of(cliente));

        ResponseEntity<Cliente> response = clienteControlador.update(1L, cliente);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(cliente, response.getBody());
    }

    @Test
    void testUpdateNotFound() {
        when(clienteServicio.update(anyLong(), any(Cliente.class))).thenReturn(Optional.empty());

        ResponseEntity<Cliente> response = clienteControlador.update(1L, cliente);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testDelete() {
        when(clienteServicio.delete(anyLong())).thenReturn(Optional.of(cliente));

        ResponseEntity<?> response = clienteControlador.delete(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(cliente, response.getBody());
    }

    @Test
    void testDeleteNotFound() {
        when(clienteServicio.delete(anyLong())).thenReturn(Optional.empty());

        ResponseEntity<?> response = clienteControlador.delete(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
}
