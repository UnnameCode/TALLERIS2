package org.jfigue.apiservlet.webapp.headers.customercrud.controllers;

import org.jfigue.apiservlet.webapp.headers.customercrud.entities.Cliente;
import org.jfigue.apiservlet.webapp.headers.customercrud.services.ClienteServicio;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/clientes")
public class ClienteControlador  {


    private final ClienteServicio clienteServicio;

    public ClienteControlador(ClienteServicio clienteServicio) {
        this.clienteServicio = clienteServicio;
    }

    @GetMapping
    public List<Cliente> list(){
        return clienteServicio.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> view (@PathVariable Long id){
        Optional<Cliente> ClienteOptional = clienteServicio.findById(id);
        if (ClienteOptional.isPresent()){
            return ResponseEntity.ok(ClienteOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Cliente> create (@RequestBody Cliente Cliente){
        return ResponseEntity.status(HttpStatus.CREATED).body(clienteServicio.save(Cliente));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cliente> update(@PathVariable Long id, @RequestBody Cliente Cliente){
        Optional<Cliente> ClienteOptional = clienteServicio.update(id, Cliente);
        if(ClienteOptional.isPresent()){
            return ResponseEntity.status(HttpStatus.CREATED).body(clienteServicio.update(id, Cliente).get());
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id){
        Optional<Cliente> ClienteOptional = clienteServicio.delete(id);

        if (ClienteOptional.isPresent()){
            return ResponseEntity.ok(ClienteOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

}
