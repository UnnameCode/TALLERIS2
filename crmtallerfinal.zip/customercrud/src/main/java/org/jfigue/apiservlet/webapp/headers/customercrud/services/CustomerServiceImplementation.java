    package org.jfigue.apiservlet.webapp.headers.customercrud.services;


    import org.jfigue.apiservlet.webapp.headers.customercrud.entities.Cliente;
    import org.jfigue.apiservlet.webapp.headers.customercrud.repositories.ClienteRepositorio;
    import org.springframework.stereotype.Service;

    import java.util.List;
    import java.util.Optional;

    @Service
    public class CustomerServiceImplementation implements ClienteServicio{

        private ClienteRepositorio clienteRepositorio;

        public CustomerServiceImplementation(ClienteRepositorio clienteRepositorio) {
            this.clienteRepositorio = clienteRepositorio;
        }

        @Override
        public List<Cliente> findAll() {
            return (List<Cliente>)clienteRepositorio.findAll();
        }

        @Override
        public Optional<Cliente> findById(Long id) {
            return clienteRepositorio.findById(id);
        }

        @Override
        public Cliente save(Cliente cliente) {
            return clienteRepositorio.save(cliente);
        }

        @Override
        public Optional<Cliente> update(Long id, Cliente cliente) {
            Optional<Cliente> clienteOptional = clienteRepositorio.findById(id);
            if(clienteOptional.isPresent()){
                Cliente clientebasededatos = clienteOptional.orElseThrow();

                clientebasededatos.setNombre(cliente.getNombre());
                clientebasededatos.setApellidos(cliente.getApellidos());
                clientebasededatos.setCorreoElectronico(cliente.getCorreoElectronico());
                clientebasededatos.setTelefono(cliente.getTelefono());
                return Optional.of(clienteRepositorio.save(clientebasededatos));
            }

            return clienteOptional;
        }

        @Override
        public Optional<Cliente> delete(Long id) {
            Optional<Cliente> clienteOptional = clienteRepositorio.findById(id);
            clienteOptional.ifPresent(clienteRepositorio::delete);
            return clienteOptional;
        }
    }
