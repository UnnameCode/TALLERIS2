package org.jfigue.apiservlet.webapp.headers.customercrud.repositories;

import org.jfigue.apiservlet.webapp.headers.customercrud.entities.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ClienteRepositorio extends CrudRepository<Cliente, Long> {


}

