package org.jfigue.apiservlet.webapp.headers.customercrud.services;

import org.jfigue.apiservlet.webapp.headers.customercrud.entities.Cliente;

import java.util.List;
import java.util.Optional;

public interface ClienteServicio {

    List<Cliente> findAll();

    Optional<Cliente> findById(Long id);

    Cliente save(Cliente cliente);

    Optional<Cliente> update(Long id, Cliente product );

    Optional<Cliente> delete(Long id);
}
