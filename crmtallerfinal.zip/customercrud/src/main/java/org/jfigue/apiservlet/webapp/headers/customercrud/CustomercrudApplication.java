package org.jfigue.apiservlet.webapp.headers.customercrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomercrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomercrudApplication.class, args);
    }

}
